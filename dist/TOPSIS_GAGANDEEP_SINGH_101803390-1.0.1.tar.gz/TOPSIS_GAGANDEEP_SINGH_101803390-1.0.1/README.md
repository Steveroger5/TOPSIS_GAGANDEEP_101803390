# Topsis Package by Gagandeep Singh 101803390

This package gives the function save_topsis(input,weights,target,output) which takes four parameters:
    1. input : is the location of input file
    2. weight : this takes the input value of every parameter weights "0.1,0.2,0.3,0.4"
    3. target : this takes the +ve and -ve as input to take whether to maximize or minimize a parameter
    4. output : is the location of the csv file where u want to save it


[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
